# Copyright (c) Recommenders contributors.
# Licensed under the MIT License.

__title__ = "Recommenders"
__version__ = "1.1.1"
__author__ = "RecoDev Team at Microsoft"
__license__ = "MIT"
__copyright__ = "Copyright 2018-present Recommenders contributors."

# Synonyms
TITLE = __title__
VERSION = __version__
AUTHOR = __author__
LICENSE = __license__
COPYRIGHT = __copyright__
